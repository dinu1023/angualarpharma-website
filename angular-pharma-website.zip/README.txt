Angular Pharma - Minimal Vite + React starter

Files included:
- package.json
- index.html
- src/main.jsx
- src/AngularPharmaSite.jsx
- src/styles.css
- vite.config.js

How to run locally:
1) npm install
2) npm run dev

To deploy to Vercel: Create a new project and upload the folder or connect GitHub repository.
